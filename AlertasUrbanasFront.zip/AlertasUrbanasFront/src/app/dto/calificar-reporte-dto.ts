export class CalificarReporteDTO {
    constructor(
      public estrellas: string = '',
    ) {}
  }
  