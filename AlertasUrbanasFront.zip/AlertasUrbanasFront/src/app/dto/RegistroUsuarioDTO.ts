export interface RegistroUsuarioDTO {
  nombre: string;
  fotoPerfil: string;
  nickname: string;
  email: string;
  password: string;
  confirmaPassword: string;
  ciudadResidencia: string;
}
