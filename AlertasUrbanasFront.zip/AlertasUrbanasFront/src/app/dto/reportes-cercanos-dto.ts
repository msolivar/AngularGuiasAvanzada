export class ReportesCercanosDTO {
    constructor(
      public latitud: string = '',
      public longitud: string = '',
    ) {}
  }
  