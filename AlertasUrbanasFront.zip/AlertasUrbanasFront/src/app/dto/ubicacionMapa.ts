export class UbicacionMapa {
  constructor(
    public x: number=0.1,
    public y: number=0.1
  ) {}

}
