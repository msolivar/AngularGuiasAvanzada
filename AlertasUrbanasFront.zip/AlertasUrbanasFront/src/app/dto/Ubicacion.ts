export class Ubicacion {
  constructor(
    public latitud: number=0,
    public longitud: number=0
  ) {}

}
