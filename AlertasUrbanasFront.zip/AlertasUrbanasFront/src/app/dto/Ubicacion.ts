export class Ubicacion {
  constructor(
    public latitud: number=0.1,
    public longitud: number=0.1
  ) {}

}
