export class MensajeDTO {
    constructor(
        public error: boolean, 
        public respuesta: any,
        public token: any,
    ) { }
}
