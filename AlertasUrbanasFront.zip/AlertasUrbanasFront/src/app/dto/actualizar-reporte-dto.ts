export class ActualizarReporteDTO {
    constructor(
        public nombre: string = '',
        public descripcion: string = '',
        public categoria: string = '',
    ) { }
}
