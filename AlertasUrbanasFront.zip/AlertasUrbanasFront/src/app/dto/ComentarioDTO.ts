export class ComentarioDTO{
    constructor(
        public comentarioTexto: string = '',
        public fecha: string = '',
    ) { }
}