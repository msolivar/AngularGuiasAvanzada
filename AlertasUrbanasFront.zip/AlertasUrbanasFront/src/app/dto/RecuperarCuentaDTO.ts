export class RecuperarCuentaDTO {
    constructor(
        public email: string = ''
    ) { }
}
