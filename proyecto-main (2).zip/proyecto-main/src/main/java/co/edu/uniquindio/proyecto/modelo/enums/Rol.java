package co.edu.uniquindio.proyecto.modelo.enums;

public enum Rol {
    CLIENTE,
    ADMINISTRADOR
}
