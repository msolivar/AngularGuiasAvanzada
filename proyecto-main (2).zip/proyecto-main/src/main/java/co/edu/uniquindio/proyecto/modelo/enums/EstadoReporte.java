package co.edu.uniquindio.proyecto.modelo.enums;

public enum EstadoReporte {
        PENDIENTE, VERIFICADO, RECHAZADO, ELIMINADO, RESUELTO

}