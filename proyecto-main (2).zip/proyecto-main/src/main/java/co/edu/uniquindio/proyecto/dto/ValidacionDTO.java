package co.edu.uniquindio.proyecto.dto;

public record ValidacionDTO(
        String campo,
        String mensaje
) {
}
