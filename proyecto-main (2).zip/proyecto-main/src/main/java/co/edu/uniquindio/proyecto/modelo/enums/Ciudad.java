package co.edu.uniquindio.proyecto.modelo.enums;

public enum Ciudad {
    ARMENIA,
    PEREIRA,
    MANIZALES,
    BOGOTA,
    CALI,
    MEDELLIN
}
