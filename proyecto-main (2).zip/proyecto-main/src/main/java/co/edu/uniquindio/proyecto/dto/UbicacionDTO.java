package co.edu.uniquindio.proyecto.dto;

public record UbicacionDTO(
        double latitud,
        double longitud
) {
}