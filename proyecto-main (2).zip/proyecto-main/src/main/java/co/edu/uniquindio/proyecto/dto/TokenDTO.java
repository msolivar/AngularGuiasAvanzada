package co.edu.uniquindio.proyecto.dto;

import java.time.Instant;

public record TokenDTO(String token) {
}


