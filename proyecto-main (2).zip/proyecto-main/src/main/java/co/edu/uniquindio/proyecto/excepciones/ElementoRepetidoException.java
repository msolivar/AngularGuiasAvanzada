package co.edu.uniquindio.proyecto.excepciones;

public class ElementoRepetidoException extends Exception{

    public ElementoRepetidoException(String mensaje) {
        super(mensaje);
    }

}
