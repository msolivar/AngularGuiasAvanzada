package co.edu.uniquindio.proyecto.modelo.enums;

public enum EstadoUsuario {
    ACTIVO,
    INACTIVO,
    ELIMINADO
}
