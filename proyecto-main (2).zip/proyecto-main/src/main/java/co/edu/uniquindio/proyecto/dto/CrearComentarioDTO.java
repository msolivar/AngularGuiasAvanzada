package co.edu.uniquindio.proyecto.dto;

public record CrearComentarioDTO(
        String comentarioTexto
) {}
