package co.edu.uniquindio.proyecto.excepciones;

public class RecursoNoEncontradoException extends Exception{

    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }

}
